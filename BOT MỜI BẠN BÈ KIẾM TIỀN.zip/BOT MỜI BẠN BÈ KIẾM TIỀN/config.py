#Bot Code By GK

TOKEN = ''