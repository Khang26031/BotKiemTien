import telebot
from telebot import types
import sqlite3
import config

bot = telebot.TeleBot(config.TOKEN)

# Kết nối database
conn = sqlite3.connect('referral.db', check_same_thread=False)
cursor = conn.cursor()


cursor.execute('''
CREATE TABLE IF NOT EXISTS users (
    user_id INTEGER PRIMARY KEY,
    username TEXT,
    first_name TEXT,
    last_name TEXT,
    balance INTEGER DEFAULT 0,
    invited_by INTEGER DEFAULT 0,
    referral_count INTEGER DEFAULT 0,
    is_admin INTEGER DEFAULT 0
)
''')
conn.commit()

# Hàm kiểm tra admin
def is_admin(user_id):
    cursor.execute('SELECT is_admin FROM users WHERE user_id = ?', (user_id,))
    result = cursor.fetchone()
    return result and result[0] == 1


@bot.message_handler(commands=['start'])
def start(message):
    user_id = message.from_user.id
    username = message.from_user.username
    first_name = message.from_user.first_name
    last_name = message.from_user.last_name
    
    #
    cursor.execute('SELECT * FROM users WHERE user_id = ?', (user_id,))
    if cursor.fetchone() is None:
        # Thêm user mới vào database
        cursor.execute('INSERT INTO users (user_id, username, first_name, last_name) VALUES (?, ?, ?, ?)',
                      (user_id, username, first_name, last_name))
        conn.commit()
        
        # Kiểm tra referral từ link mời
        if len(message.text.split()) > 1:
            referrer_id = message.text.split()[1]
            try:
                referrer_id = int(referrer_id)
                # Cập nhật thông tin người mời
                cursor.execute('UPDATE users SET referral_count = referral_count + 1 WHERE user_id = ?', (referrer_id,))
                cursor.execute('UPDATE users SET invited_by = ? WHERE user_id = ?', (referrer_id, user_id))
                # Thưởng cho người mời
                cursor.execute('UPDATE users SET balance = balance + 100 WHERE user_id = ?', (referrer_id,))
                conn.commit()
                bot.send_message(referrer_id, f'🎉 Bạn vừa có thêm 1 người tham gia qua link của bạn! Nhận ngay 100đ vào tài khoản!')
            except ValueError:
                pass
    
    # Tạo bàn phím lệnh
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    btn1 = types.KeyboardButton('💰 Kiểm tra số dư')
    btn2 = types.KeyboardButton('📊 Thống kê')
    btn3 = types.KeyboardButton('👥 Mời bạn bè')
    btn4 = types.KeyboardButton('📝 Hướng dẫn')
    markup.add(btn1, btn2, btn3, btn4)
    
    # Thêm nút admin nếu là admin
    if is_admin(user_id):
        admin_btn = types.KeyboardButton('👑 Admin Panel')
        markup.add(admin_btn)
    
    bot.send_message(message.chat.id, 
                    f"👋 Xin chào {first_name}!\n\n"
                    "🔗 Đây là bot kiếm tiền từ việc mời bạn bè. Mỗi khi có người tham gia bằng link của bạn, "
                    "bạn sẽ nhận được 100đ vào tài khoản!\n\n"
                    "📌 Sử dụng các nút bên dưới để điều khiển bot:",
                    reply_markup=markup)

# Xử lý nút Kiểm tra số dư
@bot.message_handler(func=lambda message: message.text == '💰 Kiểm tra số dư')
def check_balance(message):
    user_id = message.from_user.id
    cursor.execute('SELECT balance FROM users WHERE user_id = ?', (user_id,))
    balance = cursor.fetchone()[0]
    bot.send_message(message.chat.id, f"💰 Số dư hiện tại của bạn: {balance}đ")

# Xử lý nút Thống kê
@bot.message_handler(func=lambda message: message.text == '📊 Thống kê')
def stats(message):
    user_id = message.from_user.id
    cursor.execute('SELECT referral_count, balance FROM users WHERE user_id = ?', (user_id,))
    result = cursor.fetchone()
    referral_count, balance = result if result else (0, 0)
    
    bot.send_message(message.chat.id, 
                    f"📊 Thống kê cá nhân:\n\n"
                    f"👥 Số người đã mời: {referral_count}\n"
                    f"💰 Số dư hiện tại: {balance}đ")

# Xử lý nút Mời bạn bè
@bot.message_handler(func=lambda message: message.text == '👥 Mời bạn bè')
def invite_friends(message):
    user_id = message.from_user.id
    bot_name = bot.get_me().username
    invite_link = f"https://t.me/{bot_name}?start={user_id}"
    
    bot.send_message(message.chat.id,
                    f"📣 Mời bạn bè kiếm tiền cùng bạn!\n\n"
                    f"🔗 Link mời của bạn:\n{invite_link}\n\n"
                    f"💰 Mỗi người tham gia bằng link này, bạn nhận ngay 100đ!")

# Xử lý nút Hướng dẫn
@bot.message_handler(func=lambda message: message.text == '📝 Hướng dẫn')
def guide(message):
    bot.send_message(message.chat.id,
                    "📌 Hướng dẫn sử dụng:\n\n"
                    "1. Nhấn '👥 Mời bạn bè' để lấy link giới thiệu\n"
                    "2. Chia sẻ link này với bạn bè\n"
                    "3. Khi họ tham gia bằng link của bạn, bạn nhận ngay 100đ\n"
                    "4. Kiếm tiền không giới hạn từ việc mời bạn bè\n\n"
                    "💰 Bạn có thể kiểm tra số dư và thống kê bất cứ lúc nào!")

# Xử lý Admin Panel
@bot.message_handler(func=lambda message: message.text == '👑 Admin Panel' and is_admin(message.from_user.id))
def admin_panel(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    btn1 = types.KeyboardButton('📢 Gửi thông báo')
    btn2 = types.KeyboardButton('👥 Tổng số user')
    btn3 = types.KeyboardButton('🔙 Quay lại')
    markup.add(btn1, btn2, btn3)
    
    bot.send_message(message.chat.id, "👑 Chào mừng đến với Admin Panel", reply_markup=markup)

# Xử lý các chức năng admin
@bot.message_handler(func=lambda message: is_admin(message.from_user.id))
def handle_admin_commands(message):
    if message.text == '📢 Gửi thông báo':
        msg = bot.send_message(message.chat.id, "Nhập nội dung thông báo bạn muốn gửi đến tất cả users:")
        bot.register_next_step_handler(msg, send_announcement)
    elif message.text == '👥 Tổng số user':
        cursor.execute('SELECT COUNT(*) FROM users')
        count = cursor.fetchone()[0]
        bot.send_message(message.chat.id, f"Tổng số user: {count}")
    elif message.text == '🔙 Quay lại':
        start(message)

# Hàm gửi thông báo đến tất cả users
def send_announcement(message):
    text = message.text
    cursor.execute('SELECT user_id FROM users')
    users = cursor.fetchall()
    
    for user in users:
        try:
            bot.send_message(user[0], f"📢 Thông báo từ Admin:\n\n{text}")
        except:
            continue
    
    bot.send_message(message.chat.id, f"Đã gửi thông báo đến {len(users)} users!")



bot.polling(none_stop=True)